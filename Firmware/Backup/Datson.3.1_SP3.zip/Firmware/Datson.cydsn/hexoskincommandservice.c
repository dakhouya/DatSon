/*****************************************************************************
* Included headers
*****************************************************************************/
#include "hexoskincommandservice.h"

extern commandManager_t commandManager;
/*******************************************************************************
* Constants
*******************************************************************************/
/*Characteristic handle definitions*/
#define COMMAND_HANDLE  (cyBle_customs[CYBLE_SERIAL_PORT_SERVICE_INDEX]).customServiceInfo[CYBLE_SERIAL_PORT_RX_CHAR_INDEX].customServiceCharHandle

/*******************************************************************************
* Private Prototype
*******************************************************************************/

/*******************************************************************************
* Public Function
*******************************************************************************/
/*******************************************************************************
* Function Name: HexoskinCommandServiceInit
********************************************************************************
*
* Summary:
*  Initialize hexoskin command service structure
*
* Parameters:
*  command - Hexoskin command Service structure
*
* Return:
*  None
*
*******************************************************************************/
void HexoskinCommandServiceInit(hexoskinCommandService_t* command){
    command->hexoskinManager = &commandManager;
}

/*******************************************************************************
* Function Name: HexoskinCommandServiceCharacteristicHandler
********************************************************************************
*
* Summary:
*  Handle hexoskin command characteristics
*
* Parameters:
*  command - Hexoskin command Service structure
*  eventParam - Event parameter from main event handler
*
* Return:
*  hexoskinCommandServiceError_t status
*
*******************************************************************************/
hexoskinCommandServiceError_t HexoskinCommandServiceCharacteristicHandler(hexoskinCommandService_t* command, void* eventParam){
    hexoskinCommandServiceError_t status = ERROR_HEXOSKIN_COMMAND_SERVICE_NONE;
    /*Received handle to characteristic*/
    CYBLE_GATT_DB_ATTR_HANDLE_T handle = ((CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam)->handleValPair.attrHandle;

    /* Send command*/
    if(handle == COMMAND_HANDLE){
    CommandManagerSendPassthroughtCommand(command->hexoskinManager, 
                                        ((CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam)->handleValPair.value.val,
                                        ((CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam)->handleValPair.value.len);     
    }
    else{
        status = ERROR_HEXOSKIN_COMMAND_SERVICE_WRONG_PARAMETER;
    }
    return status;
}

/* [] END OF FILE */
