/*! \file bleprotocol.h  
  * \brief uart protocol that pipeline the commands between the 
  * \brief ble link and the uart interface to the external mcu
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/****************************************************************************/
#ifndef __BLEPROTOCOL_H__
#define __BLEPROTOCOL_H__
/****************************************************************************/
   
#define HOST_RESOLVE_PVT_ADDR 
/*****************************************************************************
* Included headers
*****************************************************************************/
#include <project.h>
/*****************************************************************************
* Type definition 
*****************************************************************************/
typedef enum{
    ERROR_BLE_PROTOCOL_NONE,                         /*!< No error >!*/     
    ERROR_BLE_PROTOCOL_TIMEOUT,                      /*!< Timeout error >!*/
    ERROR_BLE_PROTOCOL_DECODER,                      /*!< Decoding error >!*/
    ERROR_BLE_PROTOCOL_REGISTER_CALLBACK,            /*!< Callback registration error >!*/   
    ERROR_BLE_PROTOCOL_UART_BUFFER_NOT_EMPTY,        /*!< Uart buffer is not empty >!*/     
    ERROR_BLE_PROTOCOL_WRONG_DATA_LENGTH             /*!< Buffer length parameter error >!*/     
}bleProtocolError_t;

typedef struct bleProtocol bleProtocol_t;          /*!< bleProtocol structure >!*/     
typedef void (*bleProtocolNotifyFct_t)(void* context,
                                          uint8_t* data, 
                                          uint8_t length); /*!< Callback function type >!*/     

/*****************************************************************************
* Public functions
*****************************************************************************/
/*! Function that initialize the ble protocol
 *  \return bleProtocol_t*
 */
bleProtocol_t* BleProtocolInit(void);

/*! Function that will process the rx and tx data. It need
 *  to be called in the main loop (while(1))
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolProcess(bleProtocol_t* ble);

/*! Function that send a command to send on the uart interface
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  command pointer to the command buffer  
 *  \param  length length of the command buffer
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolSendCommand(bleProtocol_t* ble, uint8_t* command, uint16_t length);

/*! Function that register a callback function for a receiving command notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterCmdNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

/*! Function that register a callback function for a receiving ble info command notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterBleCmdNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

/*! Function that register a callback function for a receiving high level data notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterHighLevelNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

/*! Function that register a callback function for a receiving raw data notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterRawNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

/*! Function that register a callback function for a receiving playback data notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterPlaybackNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

/*! Function that register a callback function for a receiving any data notification
 *  from the decoder
 *  \param  ble pointer to the bleProtocol_t structure  
 *  \param  ctx context for the callback function 
 *  \param  fct callback function
 *  \return bleProtocolError_t status
 */
bleProtocolError_t BleProtocolRegisterPassthroughNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct);

#endif  /* __BLEPROTOCOL_H__ */

/* [] END OF FILE */
