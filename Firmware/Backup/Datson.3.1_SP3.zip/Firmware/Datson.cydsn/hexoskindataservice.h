/*! \file hexoskindataservice.h
  * \brief watchdog timer library
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/****************************************************************************/
#ifndef __HEXOSKINDATASERVICE_H__
#define __HEXOSKINDATASERVICE_H__

/*****************************************************************************
* Included headers
*****************************************************************************/
#include <project.h>

/*****************************************************************************
* Constant
*****************************************************************************/
#define DATA_PACKET_SIZE (20)             /*!< Data packet size >!*/
#define HEXOSKIN_DATA_NOTIFICATION_ENABLE  (1)
#define HEXOSKIN_DATA_NOTIFICATION_DISABLE (0)

/*****************************************************************************
* Type definition
*****************************************************************************/
typedef enum{
    ERROR_HEXOSKIN_DATA_SERVICE_NONE,           /*!< No error >!*/
    ERROR_HEXOSKIN_DATA_SERVICE_WRONG_PARAMETER,/*!< Wrong event parameter >!*/
    ERROR_HEXOSKIN_DATA_SERVICE_NOTIFICATION    /*!< Notification error >!*/
}hexoskinDataServiceError_t;

typedef struct{
    uint8_t txPacket[DATA_PACKET_SIZE]; /*!< tx buffer >!*/
    uint8_t txNotify;                   /*!< tx notification flag >!*/
}hexoskinDataService_t;

/*****************************************************************************
* Public functions
*****************************************************************************/
/*! Function that initialize the hexoskin data service structure.
 *  \param data pointer to hexoskinDataService_t structure
 */
void HexoskinDataServiceInit(hexoskinDataService_t* data);

/*! Function that send a tx notification
 *  \param data pointer to hexoskinDataService_t structure
 *  \param dataLength lenght of the data to send. Between ]0, DATA_PACKET_SIZE]
 *  \return hexoskinDataServiceError_t status
 */
hexoskinDataServiceError_t HexoskinDataServiceTxNotificationCCCD(hexoskinDataService_t* data, uint8_t dataLength);

/*! Function that handle the CCCD flag. Notification enable or disable
 *  \param data pointer to hexoskinDataService_t structure
 *  \param eventParam pointer to event parameter
 *  \return hexoskinDataServiceError_t status
 */
hexoskinDataServiceError_t HexoskinDataServiceNotificationHandler(hexoskinDataService_t* data, void* eventParam);

/*! Reset the notification flag. Should be used when there's a ble disconnection.
 *  \param data pointer to hexoskinDataService_t structure
 */
void HexoskinDataServiceReset(hexoskinDataService_t* data);

#endif  /* __HEXOSKINDATASERVICE_H__ */

/* [] END OF FILE */
