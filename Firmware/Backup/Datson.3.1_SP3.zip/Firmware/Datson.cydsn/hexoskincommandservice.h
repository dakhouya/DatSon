/*! \file hexoskincommandservice.h  
  * \brief watchdog timer library
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/****************************************************************************/
#ifndef __HEXOSKINCOMMANDSERVICE_H__
#define __HEXOSKINCOMMANDSERVICE_H__
/****************************************************************************/

/*****************************************************************************
* Included headers
*****************************************************************************/
#include <project.h>
#include "commandmanager.h"
    
/*****************************************************************************
* Type definition 
*****************************************************************************/  
typedef enum{
    ERROR_HEXOSKIN_COMMAND_SERVICE_NONE,            /*!< No error >!*/
    ERROR_HEXOSKIN_COMMAND_SERVICE_WRONG_PARAMETER  /*!< Wrong event parameter >!*/
}hexoskinCommandServiceError_t;
    
typedef struct hexoskinCommandService
{     
    commandManager_t* hexoskinManager;
}hexoskinCommandService_t;
/*****************************************************************************
* Public functions
*****************************************************************************/
/*! Function that Initialize hexoskin command service structure
 *  \param command pointer to hexoskin command Service structure
 */
void HexoskinCommandServiceInit(hexoskinCommandService_t* command);

/*! Function that handle hexoskin command characteristics
 *  \param command pointer to hexoskin command Service structure
 *  \param eventParam event parameter from main event handler
 *  \return hexoskinCommandServiceError_t status
 */
hexoskinCommandServiceError_t HexoskinCommandServiceCharacteristicHandler(hexoskinCommandService_t* command, void* eventParam);

#endif /* __HEXOSKINCOMMANDSERVICE_H__ */   

/* [] END OF FILE */
