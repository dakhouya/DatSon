/*! \file commandmanager.h  
  * \brief uart protocol that pipeline the commands between the msp430 and ble module
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/****************************************************************************/
#ifndef __COMMAND_MANAGER_H__
#define __COMMAND_MANAGER_H__
/****************************************************************************/
    
/*****************************************************************************
* Included headers
*****************************************************************************/
#include <project.h>
#include "uartbuffer.h"
#include "bleprotocol.h"
#include "pt.h"
#include <string.h>
   
/*****************************************************************************
* Constant
*****************************************************************************/
#define COMMAND_QUEUE_SIZE (10u) /*!< Size of the command queue >!*/
    
/*****************************************************************************
* Type definitions
*****************************************************************************/
 typedef enum{
    ERROR_COMMAND_MANAGER_NONE,
    ERROR_COMMAND_MANAGER_TIMEOUT,
    ERROR_COMMAND_MANAGER_INIT,
    ERROR_COMMAND_MANAGER_REQUEST_BUFFER_FULL
}commandManagerError_t;
    
/*Callback function*/
typedef bleProtocolNotifyFct_t commandManagerCallback_t; /*!< Callback function type >!*/
/*Definition : void (*bleProtocolNotifyFct_t)(void* context,uint8_t* data, uint8_t length) */
    
/*Command types*/
typedef enum{
    NONE_TYPE               = 0,    /*!< No Command >!*/
    CONFIG_MODE             = 'C',  /*!< Configuration mode >!*/
    DATA_MODE               = 'D',  /*!< Data mode >!*/
    ERROR_CHARACTER         = 'E',  /*!< Error >!*/
    EM_BATTERY_LEVEL        = 'L',  /*!< Battery leve >!*/
    EM_RTC                  = 'H',  /*!< Time UTC >!*/
    EM_GENERAL_INFORMATION  = 'I',  /*!< General information >!*/
    EM_STATUS               = '^',  /*!< Device status >!*/
    RECORDER_DATA_MODE      = 'd',  /*!< Recorder data mode >!*/
    RECORDER_DEFAULT_ID     = 'U',  /*!< User ID >!*/
    RECORDER_STATUS         = 'x'   /*!< Recorder status >!*/
}commandType_t;

/*Direction*/
typedef enum{
    NONE_DIRECTION  = 0,    /*!< No command >!*/
    READ_MODE       = '?',  /*!< Read command >!*/
    WRITE_MODE      = '!',  /*!< Write command >!*/
}commandDirection_t;

/*Request*/
typedef struct{
    commandDirection_t direction;      /*!< Command direction >!*/
    commandType_t type;                /*!< Command type >!*/
    void* commandSource;               /*!< Callback function context >!*/
    commandManagerCallback_t callback; /*!< Callback function >!*/
}commandRequest_t;

/*Command manager*/
typedef struct CommandManager{
    bleProtocol_t* bleProtocol;                     /*!< bleProtocol structure >!*/
    struct pt mainPt;                               /*!< Main protothread >!*/
    uint8_t rdPtr;                                  /*!< Read pointer for the command buffer >!*/
    uint8_t wrPtr;                                  /*!< Write pointer for the command buffer >!*/
    uint8_t count;                                  /*!< Number of command in the command buffer >!*/
    commandRequest_t request[COMMAND_QUEUE_SIZE];   /*!< Command buffer >!*/
    uint16_t timeout;                               /*!< Timeout flag >!*/
    commandManagerError_t lastError;                /*!< Last error >!*/
    uint8_t requestEndFlag;                         /*!< Request done flag >!*/
}commandManager_t;

/*****************************************************************************
* Public functions
*****************************************************************************/
/*! Function that initialize the command manager
 *  \param  manager pointer to the commandManager_t structure 
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerInit(commandManager_t* manager);

/*! Function that initialize the command manager
 *  \param  manager pointer to the commandManager_t structure 
 *  \return int16_t status 1 when working, 0 when processing is done, -1 when there's an error 
 */
int16_t CommandManagerProcess(commandManager_t* manager);

/*! Function that send a get recorder default ID command to msp430
 *  \param  manager pointer to the commandManager_t structure 
 *  \param  source context of the sender 
 *  \param  callback callback function
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerSendRecorderDefaultIdCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback);

/*! Function that send a get time command to msp430
 *  \param  manager pointer to the commandManager_t structure 
 *  \param  source context of the sender 
 *  \param  callback callback function
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerSendTimeCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback);

/*! Function that send a get general information command to msp430
 *  \param  manager pointer to the commandManager_t structure 
 *  \param  source context of the sender 
 *  \param  callback callback function
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerSendEmGeneralInformationCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback);

/*! Function that send a get the battery level command to msp430
 *  \param  manager pointer to the commandManager_t structure 
 *  \param  source context of the sender 
 *  \param  callback callback function
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerSendBatteryLevelCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback);

/*! Function that send a cutom command to the msp430
 *  \param  manager pointer to the commandManager_t structure 
 *  \param  command command pointer
 *  \param  length command length
 *  \return commandManagerError_t status
 */
commandManagerError_t CommandManagerSendPassthroughtCommand(commandManager_t* manager, uint8_t* command, uint16_t length);

#endif /* __COMMAND_MANAGER_H__ */  

/* [] END OF FILE */
