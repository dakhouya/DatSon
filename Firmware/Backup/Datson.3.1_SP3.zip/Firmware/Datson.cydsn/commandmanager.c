/*! \file commandmanager.c
  * \brief uart protocol that pipeline the commands between the msp430 and ble module
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/*****************************************************************************
* Included headers
*****************************************************************************/
#include "commandmanager.h"

/*****************************************************************************
* Macro
*****************************************************************************/
/*Direction*/
#define READ_COMMAND    ('?')
#define WRITE_COMMAND   ('!')

/*Timeout*/
#define DEFAULT_TIMEOUT (0xFFFF)

/*Module command type*/
typedef enum{
    PSOC_BLE_INFORMATION_CMD_TYPE = 'i',
    PSOC_BLE_ADDRESS_CMD_TYPE = 'a',
    PSOC_BLE_NAME_CMD_TYPE = 'n',
    PSOC_BLE_START_BOOTLOADER = 'B'
}psocBleCmdType_t;
/*******************************************************************************
* Private Prototype
*******************************************************************************/
/*! Prepare a new command
 *  \param  manager pointer to the commandManager_t structure
 *  \param  direction direction
 *  \param  command command type
 *  \param payload pointer to data
 *  \param payloadLength data length
 *  \return int16_t status
 */
int16_t _PrepareCommand(commandManager_t* manager, uint8_t direction, commandType_t command, uint8_t* payload, uint16_t payloadlLength);

/*! Command callback from decoder when a command is received
 *  \param  manager pointer to the commandManager_t structure
 *  \param  data pointer to received data
 *  \param length data length
 */
void _CmdCallback(commandManager_t* manager,uint8_t* data, uint8_t length);

/*! Ble info command callback from decoder when a command is received
 *  \param  manager pointer to the commandManager_t structure
 *  \param  data pointer to received data
 *  \param length data length
 */
void _BleCmdCallback(commandManager_t* manager,uint8_t* data, uint8_t length);

/*! Send ble module information
 *  \param  manager pointer to the commandManager_t structure
 */
void _SendPsocInformation(commandManager_t* manager);

/*! Send device bluetooth address
 *  \param  manager pointer to the commandManager_t structure
 */
void _SendPsocAddress(commandManager_t* manager);

/*! Set device name
 *  \param  manager pointer to the commandManager_t structure
 *  \param  pointer to the name data
 *  \param  length of the data
 */
void _SetPsocName(commandManager_t* manager, uint8_t* data, uint8_t length);

/*! Jump to bootloader program
 *  \param  manager pointer to the commandManager_t structure
 */
void _StartBootloader(commandManager_t* manager);

/*! Prepare next command to read
 *  \param  manager pointer to the commandManager_t structure
 */
void _NextRdCommand(commandManager_t* manager);

/*! Prepare next command to write
 *  \param  manager pointer to the commandManager_t structure
 */
void _NextWrCommand(commandManager_t* manager);

/*! Callback from sender when the data is received
 *  \param  manager pointer to the commandManager_t structure
 *  \param  data pointer to received data
 *  \param length data length
 */
void _CurrentCommandCallback(commandManager_t* manager, uint8_t* data, uint8_t length);

/*! Function that will process the command queue
 *  \param  manager pointer to the commandManager_t structure
 */
static PT_THREAD(_CommandManagerProcessPt(commandManager_t* manager));

/*******************************************************************************
* Public Function
*******************************************************************************/
/*******************************************************************************
* Function Name: commandManagerInit
********************************************************************************
*
* Summary:
*  Initializes the hexoskin manager structure
*
* Parameters:
*  manager - pointer to command manager structure to initalize
*
* Return:
*  commandManagerError_t sttatus
*
*******************************************************************************/
commandManagerError_t CommandManagerInit(commandManager_t* manager){
    commandManagerError_t status = ERROR_COMMAND_MANAGER_NONE;
    uint8_t i;

    manager->bleProtocol = BleProtocolInit();
    if(manager->bleProtocol){
        /*Register callback function*/
        BleProtocolRegisterCmdNotify(manager->bleProtocol, manager, (bleProtocolNotifyFct_t)_CmdCallback);
        BleProtocolRegisterBleCmdNotify(manager->bleProtocol, manager, (bleProtocolNotifyFct_t)_BleCmdCallback);

        /*Init pt*/
        PT_INIT(&(manager->mainPt));

        /*Init request*/
        for(i = 0; i < COMMAND_QUEUE_SIZE; i++){
            manager->request[i].direction = NONE_DIRECTION;
            manager->request[i].type = NONE_TYPE;
            manager->request[i].callback = 0;
            manager->request[i].commandSource = 0;
        }
        manager->rdPtr = 0;
        manager->wrPtr = 0;
        manager->count = 0;
        manager->timeout = DEFAULT_TIMEOUT;
        manager->requestEndFlag = 0;
        manager->lastError = 0;
    } else {
        status = ERROR_COMMAND_MANAGER_INIT;
    }
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerProcess
********************************************************************************
*
* Summary:
*  Process the inner mechanism of the library
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  int16_t status 1 when working, 0 when processing is done, -1 when there's an error
*
*******************************************************************************/
int16_t CommandManagerProcess(commandManager_t* manager){
    int16_t status = 0;

    _CommandManagerProcessPt(manager);
    status = BleProtocolProcess(manager->bleProtocol);
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerSendRecorderDefaultIdCommand
********************************************************************************
*
* Summary:
*  Function that send a get recorder default ID command to msp430
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  source - context of the sender
*  callback - callback function
*
* Return:
*  commandManagerError_t status
*
*******************************************************************************/
commandManagerError_t CommandManagerSendRecorderDefaultIdCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback){
    commandManagerError_t status = ERROR_COMMAND_MANAGER_NONE;

    if(manager->request[manager->wrPtr].type == NONE_TYPE){
        manager->request[manager->wrPtr].direction = READ_COMMAND;
        manager->request[manager->wrPtr].type = RECORDER_DEFAULT_ID;
        manager->request[manager->wrPtr].commandSource = source;
        manager->request[manager->wrPtr].callback = callback;
        _NextWrCommand(manager);
    } else {
        /*Buffer is full*/
        status = ERROR_COMMAND_MANAGER_REQUEST_BUFFER_FULL;
    }
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerSendTimeCommand
********************************************************************************
*
* Summary:
*  Function that send a get time command to msp430
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  source - context of the sender
*  callback - callback function
*
* Return:
*  commandManagerError_t status
*
*******************************************************************************/
commandManagerError_t CommandManagerSendTimeCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback){
    commandManagerError_t status = ERROR_COMMAND_MANAGER_NONE;

    if(manager->request[manager->wrPtr].type == NONE_TYPE){
        manager->request[manager->wrPtr].direction = READ_COMMAND;
        manager->request[manager->wrPtr].type = EM_RTC;
        manager->request[manager->wrPtr].commandSource = source;
        manager->request[manager->wrPtr].callback = callback;
        _NextWrCommand(manager);
        status = 1;
    } else {
        /*Buffer is full*/
        status = ERROR_COMMAND_MANAGER_REQUEST_BUFFER_FULL;
    }
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerSendEmGeneralInformationCommand
********************************************************************************
*
* Summary:
*  Function that send a get general information command to msp430
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  source - context of the sender
*  callback - callback function
*
* Return:
*  commandManagerError_t status
*
*******************************************************************************/
commandManagerError_t CommandManagerSendEmGeneralInformationCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback){
    commandManagerError_t status = ERROR_COMMAND_MANAGER_NONE;

    if(manager->request[manager->wrPtr].type == NONE_TYPE){
        manager->request[manager->wrPtr].direction = READ_COMMAND;
        manager->request[manager->wrPtr].type = EM_GENERAL_INFORMATION;
        manager->request[manager->wrPtr].commandSource = source;
        manager->request[manager->wrPtr].callback = callback;
        _NextWrCommand(manager);
    } else {
        /*Buffer is full*/
        status = ERROR_COMMAND_MANAGER_REQUEST_BUFFER_FULL;
    }
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerSendBatteryLevelCommand
********************************************************************************
*
* Summary:
*  Function that send a get the battery level command to msp430
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  source - context of the sender
*  callback - callback function
*
* Return:
*  commandManagerError_t status
*
*******************************************************************************/
commandManagerError_t CommandManagerSendBatteryLevelCommand(commandManager_t* manager, void* source, commandManagerCallback_t callback){
    commandManagerError_t status = ERROR_COMMAND_MANAGER_NONE;

    if(manager->request[manager->wrPtr].type == NONE_TYPE){
        manager->request[manager->wrPtr].direction = READ_COMMAND;
        manager->request[manager->wrPtr].type = EM_BATTERY_LEVEL;
        manager->request[manager->wrPtr].commandSource = source;
        manager->request[manager->wrPtr].callback = callback;
        _NextWrCommand(manager);
    } else {
        /*Buffer is full*/
        status = ERROR_COMMAND_MANAGER_REQUEST_BUFFER_FULL;
    }
    return status;
}

/*******************************************************************************
* Function Name: CommandManagerSendPassthroughtCommand
********************************************************************************
*
* Summary:
*  Function that send a cutom command to the msp430
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  source - context of the sender
*  callback - callback function
*
* Return:
*  commandManagerError_t status
*
*******************************************************************************/
commandManagerError_t CommandManagerSendPassthroughtCommand(commandManager_t* manager, uint8_t* command, uint16_t length){
    int16_t status = BleProtocolSendCommand(manager->bleProtocol, command, length);
    return status;
}
/*******************************************************************************
* Private Functions
*******************************************************************************/
/*******************************************************************************
* Function Name: _PrepareCommand
********************************************************************************
*
* Summary:
*  Prepare a new command
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  direction - direction
*  command - command type
*  payload - pointer to data
*  payloadLength - data length
*
* Return:
*  int16_t - status
*
*******************************************************************************/
int16_t _PrepareCommand(commandManager_t* manager, uint8_t direction, commandType_t command, uint8_t* payload, uint16_t payloadlLength){
    int16_t status = 0;
    uint8_t cmd[payloadlLength+7];
    uint16_t i;

    if(direction == WRITE_COMMAND){
        /*Create write command*/
        cmd[0] = direction; //Direction
        cmd[1] = command; //Command
        cmd[2] = '0'; //Pin
        cmd[3] = '0';
        cmd[4] = '0';
        cmd[5] = '0';
        for(i = 0; i < (payloadlLength); i++){
            cmd[6+i] = payload[i];
        }
        cmd[payloadlLength+6] = '\r';
        /*Send data to uart handler*/
        status = BleProtocolSendCommand(manager->bleProtocol, cmd, (payloadlLength + 7));
    } else {
        /*Create read command*/
        cmd[0] = direction; //Direction
        cmd[1] = command; //Command
        cmd[2] = ('\r');
        status = BleProtocolSendCommand(manager->bleProtocol, cmd, 3);
    }
    return status;
}

/*******************************************************************************
* Function Name: _CmdCallback
********************************************************************************
*
* Summary:
*  Callback from decoder when a command is received
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  data - pointer to received data
*  length - data length
*
* Return:
*  int16_t - status
*
*******************************************************************************/
void _CmdCallback(commandManager_t* manager,uint8_t* data, uint8_t length){
    /*Position pointer to data start byte*/
    uint8_t* dataPtr = &(data[2]);

    /*Hx response, data[1] = packet type*/
    if(data[0] == READ_COMMAND){
    switch(data[1]){
        /*Hx recoder default ID*/
        case RECORDER_DEFAULT_ID :
            manager->requestEndFlag = 1;
            /*Send to command source when data is received and update rd pointer*/
            _CurrentCommandCallback(manager, dataPtr, length);
            break;

        /*Hx rtc value*/
        case EM_RTC:
            manager->requestEndFlag = 1;
            /*Send to command source when data is received and update rd pointer*/
            _CurrentCommandCallback(manager,dataPtr, length);
            break;

        /*Hx general information*/
        case EM_GENERAL_INFORMATION:
            manager->requestEndFlag = 1;
            /*Send to command source when data is received and update rd pointer*/
            _CurrentCommandCallback(manager,dataPtr, length);
            break;

        case ERROR_CHARACTER:
            manager->requestEndFlag = 1;
            manager->lastError = -1;
            LedGreen_Write(0);
            break;

        default:
            /*Do nothing*/
            break;
        }

    }
}

/*******************************************************************************
* Function Name: _BleCmdCallback
********************************************************************************
*
* Summary:
*  ble info command callback from decoder when a command is received
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  data - pointer to received data
*  length - data length
*
* Return:
*  int16_t - status
*
*******************************************************************************/
void _BleCmdCallback(commandManager_t* manager,uint8_t* data, uint8_t length){

    if(length != 0){
        /*To remove warning on unused length variable */
    }

    switch((psocBleCmdType_t)data[1]){
        case PSOC_BLE_INFORMATION_CMD_TYPE:
            _SendPsocInformation(manager);
            break;

        case PSOC_BLE_ADDRESS_CMD_TYPE:
            _SendPsocAddress(manager);
            break;

        case PSOC_BLE_NAME_CMD_TYPE:
            _SetPsocName(manager, data, length);
            break;

        case PSOC_BLE_START_BOOTLOADER:
            /*Will not return. Will cause a jump to the bootloader*/
            _StartBootloader(manager);
            break;
            
        default:
            break;
    }
}

/*******************************************************************************
* Function Name: _SendPsocInformation
********************************************************************************
*
* Summary:
*  Send ble module information
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
void _SendPsocInformation(commandManager_t* manager){
    CYBLE_API_RESULT_T status;
    /*Array should match maximum length response*/
    uint8_t tempResponse[42] = {0};
    uint8_t* ptr;

    ptr = tempResponse;
    /*populate the array*/
    memcpy(ptr, "bi",2);
    ptr += 2;
    /*Manufacturer*/
    status =  CyBle_DissGetCharacteristicValue(CYBLE_DIS_MANUFACTURER_NAME, 18, ptr);
    ptr += 18;
    memcpy(ptr, ",",1);
    ptr += 1;
    /*Model*/
    status =  CyBle_DissGetCharacteristicValue(CYBLE_DIS_MODEL_NUMBER, 8, ptr);
    ptr += 8;
    memcpy(ptr, ",",1);
    ptr += 1;
    /*Firmware*/
    status =  CyBle_DissGetCharacteristicValue(CYBLE_DIS_FIRMWARE_REV, 5, ptr);
    ptr += 5;
    memcpy(ptr, ",",1);
    ptr += 1;
    /*Software*/
    status =  CyBle_DissGetCharacteristicValue(CYBLE_DIS_SOFTWARE_REV, 5, ptr);
    ptr += 5;
    memcpy(ptr, "\r",1);
    /*Send data to msp430*/
    BleProtocolSendCommand(manager->bleProtocol, tempResponse, 42);
}

/*******************************************************************************
* Function Name: _SendPsocAddress
********************************************************************************
*
* Summary:
*  Send device bluetooth address
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
void _SendPsocAddress(commandManager_t* manager){
    /*Array should match maximum length response*/
    uint8_t tempResponse[15] = {0};
    uint8_t* ptr;
    CYBLE_GAP_BD_ADDR_T address;
    uint8_t hexAddress[6];
    int8_t i;
    CYBLE_API_RESULT_T status;
    
    ptr = tempResponse;
    /*populate the array*/
    memcpy(ptr, "ba",2);
    ptr += 2;
    /* Get bluetooth address */
    address.type = 0;
    status =  CyBle_GetDeviceAddress(&address);
    memcpy(hexAddress,address.bdAddr, CYBLE_GAP_BD_ADDR_SIZE);
    /*Convert Hex to ascii*/
    /*And convert Maj to Min*/
    for(i = 5; i >= 0; --i){
        /* LSB */
        if(((hexAddress[i] & 0xF0)>>4) <= 9){
            *ptr++ = ((hexAddress[i] & 0xF0)>>4) + '0'; 
        }
        else{
            *ptr++ = ((hexAddress[i] & 0xF0)>>4) + '0' + 0x27; 
        }
        
        /* MSB */
        if(((hexAddress[i] & 0x0F)) <= 9){
            *ptr++ = (hexAddress[i] & 0x0F) + '0'; 
        }
        else{
            *ptr++ = (hexAddress[i] & 0x0F) + '0' +0x27;
        }
    }
        
    memcpy(ptr, "\r",1);
    BleProtocolSendCommand(manager->bleProtocol, tempResponse, 15);
}

/*******************************************************************************
* Function Name: _SetPsocName
********************************************************************************
*
* Summary:
*  Set device name
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  data - pointer to the name data
*  length - length of the data
*
* Return:
*  None
*
*******************************************************************************/
void _SetPsocName(commandManager_t* manager, uint8_t* data, uint8_t length){
  uint8_t localName[25];
  uint8_t newName[length+1];
  uint8_t response[3] = {'b','n','\r'};
  uint8_t* ptr;
  uint8_t tempLength;
  /*Remove bn at the command begining*/
  ptr = data+2;
  tempLength = length-2;
  /*Set name with \0 at the end*/
  memcpy(newName, ptr, tempLength);
  newName[tempLength] = '\0';

  /*Get name to compare*/
  CyBle_GapGetLocalName((char8*)localName);
  if(strcmp((const char*)localName, (const char*)newName) != 0){
    /*Update Device name on ble characteristic*/
    CyBle_GapSetLocalName((char8*)newName);
    /*Need to stop advertisement to enable name changes*/
    CyBle_GappStopAdvertisement();
    CyBle_StoreStackData(1);
  }

  BleProtocolSendCommand(manager->bleProtocol, response, 3);
}

/*******************************************************************************
* Function Name: _StartBootloader
********************************************************************************
*
* Summary:
*  Jump to bootloader
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
void _StartBootloader(commandManager_t* manager){
    if(manager != 0){
        /*To remove unused variable warning*/
    }
    /*Start bootloader*/
    Bootloadable_Load();
    /*Force a software reset*/
    //CySoftwareReset();
}
/*******************************************************************************
* Function Name: _NextRdCommand
********************************************************************************
*
* Summary:
*  Prepare next command to read
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
void _NextRdCommand(commandManager_t* manager){
    /*Clear buffer at rdPtr index*/
    manager->request[manager->rdPtr].direction = NONE_DIRECTION;
    manager->request[manager->rdPtr].type = NONE_TYPE;
    manager->request[manager->rdPtr].callback = 0;
    manager->request[manager->rdPtr].commandSource = 0;

    /*Increment position in the read buffer*/
    manager->rdPtr++;

    /*Check limit value*/
    if(manager->rdPtr >= COMMAND_QUEUE_SIZE){
        manager->rdPtr = 0;
    }
    manager->count--;
}

/*******************************************************************************
* Function Name: _NextWrCommand
********************************************************************************
*
* Summary:
*  Prepare next command to write
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
void _NextWrCommand(commandManager_t* manager){
    /*Increment position in the read buffer*/
    manager->wrPtr++;
    /*Check limit value*/
    if(manager->wrPtr >= COMMAND_QUEUE_SIZE){
        manager->wrPtr = 0;
    }
    manager->count++;
}

/*******************************************************************************
* Function Name: _CurrentCommandCallback
********************************************************************************
*
* Summary:
*  Callback from sender when the data is received
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*  data - pointer to received data
*  length - data length
*
* Return:
*  None
*
*******************************************************************************/
void _CurrentCommandCallback(commandManager_t* manager, uint8_t* data, uint8_t length){
    if(manager->request[manager->rdPtr].callback){
        manager->request[manager->rdPtr].callback(manager->request[manager->rdPtr].commandSource, data, length);
    }
}

/*******************************************************************************
* Function Name: _CommandManagerProcessPt
********************************************************************************
*
* Summary:
*  Function that will process the command queue
*
* Parameters:
*  manager - pointer to the commandManager_t structure
*
* Return:
*  None
*
*******************************************************************************/
static PT_THREAD(_CommandManagerProcessPt(commandManager_t* manager)){
  manager->timeout--;
  if(manager->timeout <= 0){
    manager->lastError = ERROR_COMMAND_MANAGER_TIMEOUT;
    manager->timeout = DEFAULT_TIMEOUT;
    /*Won't change command and will retry again*/
    PT_EXIT(&(manager->mainPt));
  }
  else{
    PT_BEGIN(&(manager->mainPt));
    /*Check if there's a command*/
    if(manager->request[manager->rdPtr].type != NONE_TYPE){

        /*Send data to hx mcu*/
        _PrepareCommand(manager,manager->request[manager->rdPtr].direction, manager->request[manager->rdPtr].type, 0, 0);
        PT_WAIT_UNTIL(&(manager->mainPt), manager->requestEndFlag == 1);

        /*Prepare for next command*/
        _NextRdCommand(manager);
        manager->requestEndFlag = 0;
        manager->timeout = DEFAULT_TIMEOUT;
    }
    PT_END(&(manager->mainPt));
  }
}
/***********************************************************/

/* [] END OF FILE */
