/*! \file bleprotocol.c  
  * \brief uart protocol that pipeline the commands between the 
  * \brief ble link and the uart interface to the external mcu
  */
////**************************************************************************
// PROPRIETARY DATA NOTICE
// Copyright @ Carré Technologies inc.
// All Right Reserved. No part of this file shall be used,
// communicated, reproduced or copied in any form or by any means
// without the prior written permission of Carré Technologies inc.
//****************************************************************************

/*****************************************************************************
* Included headers
*****************************************************************************/
#include "bleprotocol.h"
#include "uartbuffer.h"
#include "decoder.h"

/*****************************************************************************
* Macro
*****************************************************************************/
/*Buffer size*/
#define DATA_BUFFER_SIZE        (256) /*!< Real time data buffer size >!*/     
#define PLAYBACK_BUFFER_SIZE    (64)  /*!< Playback data buffer size >!*/     
#define CMD_BUFFER_SIZE         (64)  /*!< Commands buffer size >!*/      

struct bleProtocol{
    decoder_t decoder;           /*!< Commands decoder >!*/
    uartBuffer_t* uartBuffer;    /*!< uart buffer to msp430 >!*/
};
/*****************************************************************************
* Global Variable
*****************************************************************************/
bleProtocol_t bleSingleton;     /*!< Single instance >!*/
static uint8_t initialized = 0; /*!< Initialization status >!*/

/*****************************************************************************
* Public function
*****************************************************************************/
/*******************************************************************************
* Function Name: BleProtocolInit
********************************************************************************
*
* Summary:
*  Initializes the ble protocol
*
* Parameters:
*  None
*
* Return:
*  bleProtocol instance (Singleton)
*
*******************************************************************************/
bleProtocol_t* BleProtocolInit(void){  
    /*Check if the structure is already initilized*/
    if(!initialized){
        bleSingleton.uartBuffer = UartBufferInit();
        
        /*Get Uartbuffer instance(singleton)*/
        if(bleSingleton.uartBuffer){
            
            /*Init decoder*/
            DecoderInit(&(bleSingleton.decoder));
            
            /*To initialize only one time*/
            initialized = 1;
        } else {
            /*Uart init fail*/
            return 0;
        }
    }
    return &bleSingleton;
}

/*****************************************************************************
* Function Name: BleProtocolProcess
******************************************************************************
*
* Summary:
*  Function that will process the rx and tx data. It need
*  to be called in the main loop (while(1))
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure  
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolProcess(bleProtocol_t* ble){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    int16_t decoderStatus;
    uint8_t byte;
    
        if(!UartBufferRxIsEmpty(ble->uartBuffer)){
            byte = UartBufferRxRead(ble->uartBuffer);
            decoderStatus = DecoderDecode(&(ble->decoder),byte);
            if(decoderStatus == -1){
                LedRed_Write(0);
                /*Check for decoder error*/
            }
            if(!UartBufferRxIsEmpty(ble->uartBuffer)){ 
                /*Need to process again*/
                status = ERROR_BLE_PROTOCOL_UART_BUFFER_NOT_EMPTY;
            }
        }
        if(!UartBufferTxIsEmpty(ble->uartBuffer)){
            UartBufferProcess(ble->uartBuffer);
            status = ERROR_BLE_PROTOCOL_UART_BUFFER_NOT_EMPTY;
        }
        /*Process done*/
        return status;
}

/*****************************************************************************
* Function Name: BleProtocolSendCommand
******************************************************************************
*
* Summary:
*  Function that send a command to send on the uart interface
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  command - pointer to the command buffer  
*  length - length of the command buffer
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolSendCommand(bleProtocol_t* ble, uint8_t* command, uint16_t length){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    if(length > 0){
        UartBufferTxAddMultipleBytes(ble->uartBuffer, command, length);
        status = 0;
    } else {
        /*Nothing to send*/
        status = ERROR_BLE_PROTOCOL_WRONG_DATA_LENGTH;
    }
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterCmdNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving command notification
*  from the decoder
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterCmdNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackCmd(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextCmd(&(ble->decoder),ctx);
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterCmdNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving ble info command 
*  notification from the decoder.
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterBleCmdNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackBleCmd(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextBleCmd(&(ble->decoder),ctx);
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterHighLevelNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving high level data
*  notification from the decoder
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterHighLevelNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackHighLevel(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextHighLevel(&(ble->decoder),ctx);
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterRawNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving raw data 
*  notification from the decoder
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterRawNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackRaw(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextRaw(&(ble->decoder),ctx);
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterPlaybackNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving playback data
*  notification from the decoder
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterPlaybackNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackPlayback(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextPlayback(&(ble->decoder),ctx);
    return status;
}

/*****************************************************************************
* Function Name: BleProtocolRegisterPassthroughNotify
******************************************************************************
*
* Summary:
*  Function that register a callback function for a receiving any notification
*  from the decoder
*
* Parameters:
*  ble - pointer to the bleProtocol_t structure   
*  ctx - context for the callback function  
*  fct - callback function
*
* Return:
*  bleProtocolError_t
*
*****************************************************************************/
bleProtocolError_t BleProtocolRegisterPassthroughNotify(bleProtocol_t* ble, void* ctx, bleProtocolNotifyFct_t fct){
    bleProtocolError_t status = ERROR_BLE_PROTOCOL_NONE;
    
    status = DecoderSetCallbackPassthrough(&(ble->decoder),(decodedDataCallback_t)fct);
    status = DecoderSetContextPassthrough(&(ble->decoder),ctx);
    return status;    
}

/* [] END OF FILE */
