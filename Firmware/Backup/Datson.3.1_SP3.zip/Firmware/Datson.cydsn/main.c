/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#define MAX_LINE (2)
#define MAX_CHAR (20)
int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    LCD_Start();
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    LCD_DisplayOn();
    LCD_Position(0u, 0u);
    LCD_PrintString("Horizontal BG");
    LCD_Position(1u, 0u);
    LCD_PrintString("Demo complete");
    PWM_1_Start();
    PWM_2_Start();
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
