/*****************************************************************************
* Included headers
*****************************************************************************/
#include <hexoskindataservice.h>

/*******************************************************************************
* Constant
*******************************************************************************/
#define MAXIMUM_PACKET_COUNT_PER_CONNECTION_INTERVAL (4) //4 for android OS, source: forums...
#define TX_CHARACTERISTIC_HANDLE (cyBle_customs[CYBLE_SERIAL_PORT_SERVICE_INDEX])  \
                                .customServiceInfo[CYBLE_SERIAL_PORT_TX_CHAR_INDEX]\
                                .customServiceCharDescriptors[CYBLE_SERIAL_PORT_TX_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX])
/*******************************************************************************
* Global Variable
*******************************************************************************/
/*Tx Notification per connection interval count*/
uint8_t packetCount; /*!< tx buffer pointer >!*/

/*******************************************************************************
* Private Prototype
*******************************************************************************/
/*! Notification interrupt to count the number of packet per connection intervals
 */
void NotificationInterrupt(void);

/*******************************************************************************
* Public Function
*******************************************************************************/
/*******************************************************************************
* Function Name: HexoskinDataServiceInit
********************************************************************************
*
* Summary:
*  Initialize the hexoskin data Service
*
* Parameters:
*  hexoskinDataService_t* data - Hexoskin Data Service object to initialize
*
* Return:
*  None
*
*******************************************************************************/
void HexoskinDataServiceInit(hexoskinDataService_t* data){
    uint8_t i;

    /*Setting Interrupt for packet count limit*/
    isrNotification_StartEx(NotificationInterrupt);
    TIMER_NOTIFICATION_Start();
    packetCount = 0;

    /*Initialise structure*/
    data->txNotify = HEXOSKIN_DATA_NOTIFICATION_DISABLE;
    for(i = 0; i < DATA_PACKET_SIZE; i++){
        data->txPacket[i] = 0;
    }
}

/*******************************************************************************
* Function Name: HexoskinDataServiceTxNotificationCCCD
********************************************************************************
*
* Summary:
*  Function that send a tx notification
*
* Parameters:
*  hexoskinDataService_t* data - Hexoskin Data Service object to initialize
*  dataLength - length of the data to send. Between ]0, DATA_PACKET_SIZE]
*
* Return:
*  hexoskinDataServiceError_t - status
*
*******************************************************************************/
hexoskinDataServiceError_t HexoskinDataServiceTxNotificationCCCD(hexoskinDataService_t* data, uint8_t data_length) {
    CYBLE_GATTS_HANDLE_VALUE_NTF_T		notificationHandle;
    hexoskinDataServiceError_t status = ERROR_HEXOSKIN_DATA_SERVICE_NONE;
    
    if(packetCount < MAXIMUM_PACKET_COUNT_PER_CONNECTION_INTERVAL && data->txNotify == HEXOSKIN_DATA_NOTIFICATION_ENABLE){
 
        /* Update notification handle data*/
    	notificationHandle.attrHandle = CYBLE_SERIAL_PORT_TX_CHAR_HANDLE;//CYBLE_HEXOSKIN_DATA_TX_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE;
    	notificationHandle.value.val = data->txPacket;
    	notificationHandle.value.len = data_length;
    	/* Send notifications. */
        packetCount++;
    	if(CyBle_GattsNotification(cyBle_connHandle, &notificationHandle) != CYBLE_ERROR_OK){
            status = ERROR_HEXOSKIN_DATA_SERVICE_NOTIFICATION;
        }
    }
    return status;
}

/*******************************************************************************
* Function Name: HexoskinDataServiceNotificationHandler
********************************************************************************
*
* Summary:
*  Function that handle the CCCD flag. Notification enable or disable
*
* Parameters:
*  hexoskinDataService_t* data - Hexoskin Data Service object to initialize
*  eventParam - pointer to event parameter from main event handler
*
* Return:
*  hexoskinDataServiceError_t - status
*
*******************************************************************************/
hexoskinDataServiceError_t HexoskinDataServiceNotificationHandler(hexoskinDataService_t* data, void* eventParam){
    if(data){

        /*tx data*/
        if(((CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam)->handleValPair.attrHandle == TX_CHARACTERISTIC_HANDLE{
            if(((CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam)->handleValPair.value.val[0] == 0x01){
                data->txNotify = HEXOSKIN_DATA_NOTIFICATION_ENABLE;
            } else {
                data->txNotify = HEXOSKIN_DATA_NOTIFICATION_DISABLE;
            }
        }
        return ERROR_HEXOSKIN_DATA_SERVICE_NONE;
    } else {
        return ERROR_HEXOSKIN_DATA_SERVICE_WRONG_PARAMETER;
    }
}

/*****************************************************************************
* Function Name: HexoskinDataServiceReset
******************************************************************************
*
* Summary:
*  Reset the notification flag. Should be used when there's a ble disconnection.
*
* Parameters:
*  hexoskinDataService_t* data - Hexoskin Data Service object to initialize
*
* Return:
*  None
*
*****************************************************************************/
void HexoskinDataServiceReset(hexoskinDataService_t* data){
  data->txNotify = HEXOSKIN_DATA_NOTIFICATION_DISABLE;
}

/*******************************************************************************
* Private Functions
*******************************************************************************/
/*******************************************************************************
* Function Name: HexoskinDataServiceNotificationHandler
********************************************************************************
*
* Summary:
*  Notification interrupt to count the number of packet per connection intervals
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void NotificationInterrupt(void){
    uint32_t source;
    
    packetCount = 0;
    /*Clear interrupt source*/
    source = TIMER_NOTIFICATION_GetInterruptSource();
    TIMER_NOTIFICATION_ClearInterrupt(source);
}

/* [] END OF FILE */
